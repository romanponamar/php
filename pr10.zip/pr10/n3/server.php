<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<title>Программирование на языке PHP</title>
</head>
<body>
	<h1>Отправка данных на сервер</h1>
	<h2>Безопасность данных, часть 2</h2>

	<?php
		$_ERROR = [];
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$login = $_POST['login'] ?? '';
			
			// Проверка на пустоту
			if (empty(trim($login))) {
				$_ERROR[] = "Логин не заполнен";
			}
			
			// Санитизация
			$login = strip_tags($login);
			
			// Валидация
			if (!preg_match('/^[a-z0-9]{5,10}$/', $login) && trim($login) !== '') {
				$_ERROR[] = "Логин должен содержать 5-10 латинских букв или цифр";
			}
			
			// Вывод результата
			if (empty($_ERROR)) {
				echo "<h3>Логин успешно отправлен!</h3>";
				echo "Логин: ", $login;
			} else {
				echo "<h3>Ошибка:</h3>";
				foreach ($_ERROR as $error) {
					echo $error;
				}
			}
		}

	?>
	

</body>
</html>