<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Программирование на языке PHP</title>
</head>
<body>
    
    <h1>Отправка данных на сервер</h1>
    <h2>Безопасность данных, часть 1</h2>
    
    <?php
        $_ERROR["valid"] = [];
        $_ERROR["empty"] = [];

        // Проверяем, отправлена ли форма
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            // Получаем данные из формы
            $login = $_POST['login'] ?? '';
            $email = $_POST['email'] ?? '';
            $pwd = $_POST['pwd'] ?? '';
            
            // 1. Проверка на пустоту
            if (trim($login) == '') {
                $_ERROR["empty"][] = "Логин не заполнен";
            }
            
            if (trim($email) == '') {
                $_ERROR["empty"][] = "E-mail не заполнен";
            }
            
            if (trim($pwd) == '') {
                $_ERROR["empty"][] = "Пароль не заполнен";
            }
            
            // 2. Если проверка на пустоту пройдена, выполняем санитизацию и валидацию
            //if (empty($_ERROR["empty"])) {
                
                // Санитизация данных
                $login = (trim($login));
                $email = (trim($email));
                $pwd = (trim($pwd));
                
                // Валидация данных
                // проверяем поле Логин
                if (!preg_match("/^[a-zA-Z0-9]+$/", $login) && trim($login) !== '') {
                    $_ERROR["valid"][] = "Логин должен содержать только латинские буквы и цифры";
                }
                
                // проверяем поле Email
                if (!filter_var($email, FILTER_VALIDATE_EMAIL) && trim($email) !== '') {
                    $_ERROR["valid"][] = "Некорректный формат E-mail";
                }
                
                // проверяем поле Пароль
                if (!preg_match("/^[a-zA-Z0-9]+$/", $pwd) && trim($pwd) !== '') {
                    $_ERROR["valid"][] = "Пароль должен содержать только латинские буквы и цифры";
                }
            //}
            
            if (empty($_ERROR["empty"]) && empty($_ERROR["valid"])) {
                echo "<h2>Форма успешно отправлена!</h2>";
                echo "<p>Логин: $login</p>";
                echo "<p>E-mail: $email</p>";
                echo "<p>Пароль: $pwd</p>";
            } else {
                
                if (!empty($_ERROR["empty"])) {
                    echo "<h3>Ошибки проверки на пустоту:</h3>";
                    foreach ($_ERROR["empty"] as $error) {
                        echo $error, '<br /><br />';
                    }
                }

                if (!empty($_ERROR["valid"])) {
                    echo "<h3>Ошибки валидации:</h3>";
                    foreach ($_ERROR["valid"] as $error) {
                        echo $error, '<br /><br />';
                    }
                }
            }
            
            echo "<hr>";
            echo "<h3>Статистика ошибок:</h3>";
            echo "<p>Ошибок проверки на пустоту: " . count($_ERROR["empty"]) . "</p>";
            echo "<p>Ошибок валидации: " . count($_ERROR["valid"]) . "</p>";
        }
    ?>    

</body>
</html>