<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    echo "<h1>На сервер приняты данные формы</h1>";
    if ($_POST['name'] != "") {
        echo "<p><i>Название группы: </i><b>{$_POST['name']}</b>,</p>";
    }
    if ($_POST['alias'] != "") {
        echo "<p><i>Алиасное имя: </i><b>{$_POST['alias']}</b>,</p>";
    }
    if ($_POST['country'] != "") {
        echo "<p><i>Страна: </i><b>{$_POST['country']}</b>,</p>";
    }
    if ($_POST['date'] != "") {
        echo "<p><i>Дата основания: </i><b>{$_POST['date']}</b>,</p>";
    }
    if ($_POST['style'] != "") {
        echo "<p><i>Стиль: </i><b>{$_POST['style']}</b>,</p>";
    }
    if ($_POST['content'] != "") {
        echo "<p><i>Контент: </i><b>{$_POST['content']}</b>.</p>";
    }

    echo "<h1>Пользователь пытается загрузить файл</h1>";
    if ($_FILES['image']['name'] != "") {
        echo "<p><i>Имя файла: </i><b>{$_FILES['image']['name']}</b>,</p>";
        echo "<p><i>Размер файла: </i><b>{$_FILES['image']['size']}</b> байт,</p>";
        echo "<p><i>Тип содержимого файла: </i><b>{$_FILES['image']['type']}</b>,</p>";
        echo "<p><i>Имя временного файла: </i><b>{$_FILES['image']['tmp_name']}</b>,</p>";
        echo "<p><i>Код ошибки: </i><b>{$_FILES['image']['error']}</b>.</p>";
    } else {
        echo "<p><i>Код ошибки: </i><b>{$_FILES['image']['error']}</b>.</p>";
        echo "Пользователь не выбрал файл";
    }

    ?>
</body>
</html>