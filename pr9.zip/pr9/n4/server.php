<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
    <?php

    $count = count($_FILES["myfile"]["name"]);
    for ($i=0; $i < $count; $i++) {
        $current_path = $_FILES["myfile"]["tmp_name"][$i];
        $filename = $i . "_" . $_FILES["myfile"]["name"]["$i"];
        $new_path = __DIR__ . '/upload/' . $filename;
        move_uploaded_file($current_path, $new_path);
    }
    echo "<h1>Файлы загружены</h1>";

    ?>
<body>
    
</body>
</html>