<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

    <form action="" method="post">
        Имя: <input type="text" value="" name="name"><p>
        Логин: <input type="text" value="" name="login"><p>
        Email: <input type="text" value="" name="email"><p>
        Пароль: <input type="text" value="" name="password"><p>

        <input type="submit">
    </form>

    <?php

    $conn = new mysqli('localhost','root','12345678','pr11n1base');
    $sql = sprintf("INSERT INTO `users`(`id`, `name`, `login`, `email`, `password`)
    VALUES (NULL,'%s','%s','%s','%s')",

    $_POST['name'],
    $_POST['login'],
    $_POST['email'],
    $_POST['password']
    );
    $result=$conn->query($sql);



    ?>
<body>
    
</body>
</html>