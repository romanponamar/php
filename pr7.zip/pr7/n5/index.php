<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

        require 'array.php';

        $encodeArray = json_encode($array);

        $decodeArray = json_decode($encodeArray);

        echo "<h2>Декодированный массив</h2>";
        echo "<pre>";
        print_r($decodeArray);
        echo "</pre>";

    ?>
</body>
</html>