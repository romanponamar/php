<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<title>Программирование на языке PHP</title>
</head>
<body>
	
	<h1>Отправка данных на сервер</h1>	
	<h2>Отправка данных в строке запроса</h2>
	<hr>
	<h2>Информация полученная из строки запроса</h2>
	
	<?php
		// информация строки запроса	
		// ...
		if (isset($_GET["album"])) {
			$album = $_GET["album"];
			echo "
				Идентификатор альбома: {$album['id']}<br />
				Название альбома: {$album['album_name']}<br />
				Дата выпуска: {$album['date']}<br />
				Лейбл студии: {$album['label']}<br />
				Формат: {$album['format']}<br />
				Статус: {$album['status']}<br />
			";
		}
	?>
	

</body>
</html>