<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<title>Программирование на языке PHP</title>
</head>
<body>
	
	<h1>Отправка данных на сервер</h1>
	<h2>Отправка данных в строке запроса</h2>
		
	<?php
		// подключаем массив с альбомами группы
		require "albums.php";
		
		// id - идентификатор альбома, информацию о котором необходимо передать	
		// можно задать в коде 
		$id = 2;
		
		// можно передать GET-параметром
		// $id = $_GET["id"];

		// объявим массив для сбора информации
		$album = array();
		
		// запускаем цикл по массиву
		foreach ($albums as $item){
			if ($item["id"] == $id) {

				foreach ($item as $key => $val) {
					if (is_array($val)) {
						$val = implode(', ', $val);
					}
				$album[] = "album[" . $key . "]=" . $val;
				}				
			}
		}
		
		// преобразуем массив в строку с разделителем &
		// ...
		$get = implode("&", $album);
		// выводим ссылку с GET-параметрами		
		// ...
		echo "<a href='server.php?" . $get . "'>Передать альбом с id = 2</a>";
	?>
	

</body>
</html>