<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<title>Программирование на языке PHP</title>
</head>
<body>

	<h1>Основы программирования</h1>
	<h2>Константы</h2>
	
	<?php
		const PINK_FLOYD = [
			'album' => 'The Dark Side of The Moon',
			'team' => 'Pink Floyd',
			'data' => '17 марта 1973',
			'label' => 'Harvest, Capitol, EMI',
			'format' => 'LP, кассета, CD, SACD',
			'status' => 'Платиновый (USA), Платиновый(GBR)'
	];

	
	?>
<p>
    Альбом: <?php echo PINK_FLOYD['album']; ?><br>
    Группа: <?php echo PINK_FLOYD['team']; ?><br>
    Дата выхода: <?php echo PINK_FLOYD['data']; ?>
</p>

</body>
</html>
