<?php

	require 'album.php';
	require 'team.php';
	
	function fnOutAlbum() {
			global $album;
			global $team;
			$tr = "";

			foreach ($album as $key => $item) {
				$count = 0;
				$n = 0;
				while ($count <= 5) {
					if ($item['id_team'] === $team[$count]['id_team']) {
						$tr .= "
							<tr>
								<td>{$item['id_album']}</td>
								<td>{$item['title']}</td>
								<td>{$item['date']}</td>
								<td>{$item['country']}</td>
								<td>{$team[$count]['name']}</td>
							</tr>	
						";
						$n++;
					};
				$count++;	
				};
				if ($n === 0) {
					$tr .= "
						<tr>
							<td>{$item['id_album']}</td>
							<td>{$item['title']}</td>
							<td>{$item['date']}</td>
							<td>{$item['country']}</td>
							<td>---</td>
						</tr>	
					";
				};
				$n = 0;
			};

			$out = "
				<table border=1 cellpadding=5>
				<tr>
					<th>ID</th>
					<th>Альбом</th>
					<th>Дата выпуска</th>
					<th>Страна</th>
					<th>Наименование группы</th>
				</tr>
				{$tr}
				</table>
			";
			
			return $out;		
		}			
	
	//function fnGetTeamName ($pteam, $id){
		// ...
?>