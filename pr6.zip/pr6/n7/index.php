<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<title>Программирование на языке PHP</title>
</head>
<body>
	<h1>Функции</h1>
	<h2>Область видимости переменных</h2>
	
	<?php

		require "fun.php";
		
		// вывод альбомов из массива album
		echo fnOutAlbum();
		
	?>
	

</body>
</html>